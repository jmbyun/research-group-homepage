from hdsp import hdsp_corpus, hdsp
import time
import utils
import numpy as np
from lda_vb import LDA

# input variables
# hdsp_corpus - corpus object for hdsp
# train_ids, train_cnt : same input type used for online-lda (http://www.cs.princeton.edu/~blei/downloads/onlineldavb.tar)
# train_responses = document x label numpy array 1 if label exists 0 otherwise
# valid_names = list of label names

# number of truncated topics
num_topic = 200
# maximum number of iteration
num_iter = 500
# vocabulary size
num_word = len(vocab)
# num iter for init hdp
init_hdp_iter = 0
# num iter for init lda
lda_init_iter = 10
# topic dirichlet prior
eta = 0.5
alpha = 0.1
isHDP = False

#initialize topics with LDA
lda = LDA(vocab, num_topic, train_ids, train_cnt, alpha, eta)
for i in xrange(lda_init_iter):
    (gamma, sstats) = lda.do_m_step(False)


#init model
model = hdsp(num_topic, len(vocab), responses.shape[1], dir_prior=eta)
_corpus = hdsp_corpus(vocab, train_ids, train_cnt, num_topic, train_responses, label_names=valid_names)

model.is_compute_lb = True
model.is_plot = True    #likelihood plot
model.is_verbose = True #print steps
model.ll_diff_frac = 1e-3   #stop criteria
model.gamma = lda._lambda.T     # lda topics
model.hdp_init_step = init_hdp_iter

lbs = model.runVariationalEM(num_iter, _corpus, isHDP) #run

model.save_result('output', _corpus)

