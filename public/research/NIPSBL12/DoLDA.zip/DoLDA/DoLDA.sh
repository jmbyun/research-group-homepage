hadoop dfs -rmr /user/hadoop_usr/output*
hadoop dfs -rmr /user/hadoop_usr/lambda*
rm -rf ./output*
time python26 DoLDA_Driver.py $1 $2 $3 $4 $5 $6 $7 $8
hadoop dfs -copyToLocal /user/hadoop_usr/output* ./